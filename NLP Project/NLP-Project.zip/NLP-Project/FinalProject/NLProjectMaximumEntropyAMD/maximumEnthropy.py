import csv
import nltk
"""
    References: http://blog.datumbox.com/machine-learning-tutorial-the-max-entropy-text-classifier/
                http://ravikiranj.net/posts/2012/code/how-build-twitter-sentiment-analyzer/
    Overview of Machine Learning Technique:
                An example of how maximum entropy works is if there are 4 text to classify and we are told that on average 40% of documents with
                the word "elections" in them are about elections. We would say that there is a 40% change of the document being related to voting and a 20% chance
                of it being any of the other 3 documents. Maximum entropy is used to estimate any probability distribution. In maximum
                entropy we use the training data to set constraints on the conditional distribution. The maxent classifier is based on
                the principle of maximum entropy and unlike the naive bayes classifier, it does not assume that the features are conditionally
                independent of each other
                Improved Iterative Scaling:
                                    This performs hillclimbing in parameter log liklihood space and is used to calculate the log liklihood of an exponential model

    Overview Of Program:
                This program scrubs the raw tweet data downloaded from twitter to make it in a more processable form. It removes common 'stop words' from each
                tweet so that the feature vectors do not have unnecessary verbose words such as "of, him, I, you etc." This program was used for positive and negative,
                which were represented with level 2 being negative and level 3 being positive. This was done so that we would be able to use a training file so that the
                program could be extended to level 1 being very negative and level 4 being very positive. The training data is in a file named "training.csv"
                The output is written to a file named "results.txt". The data to test the program on is in "inputTestTweets.txt".





"""

#========================================================================================================================

import re

# pre process the tweets eg convert all to lowercase etc so they can be in a more processable format
def processTweet(tweet):
    # process the tweets

    #Convert to lower case
    tweet = tweet.lower()
    #Convert www.* or https?://* to URL
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))','URL',tweet)
    #Convert @username to AT_USER
    tweet = re.sub('@[^\s]+','AT_USER',tweet)
    #Remove additional white spaces
    tweet = re.sub('[\s]+', ' ', tweet)
    #Replace #word with word
    tweet = re.sub(r'#([^\s]+)', r'\1', tweet)
    #trim
    tweet = tweet.strip('\'"')
    return tweet


#look for 2 or more repetitions of character and replace with the character itself
def replaceTwoOrMore(s):

    pattern = re.compile(r"(.)\1{1,}", re.DOTALL)
    return pattern.sub(r"\1\1", s)


#Get a list of all of the common words that we want to extract
def getStopWordList(stopWordListFileName):
    #read the stopwords file and build a list
    stopWords = []
    stopWords.append('AT_USER')
    stopWords.append('URL')

    fp = open(stopWordListFileName, 'r')
    line = fp.readline()
    while line:
        word = line.strip()
        stopWords.append(word)
        line = fp.readline()
    fp.close()
    return stopWords


# build a feature vector of all words that are not stop words
def getFeatureVector(tweet):
    featureVector = []
    #split tweet into words
    words = tweet.split()
    for w in words:
        #replace two or more with two occurrences
        w = replaceTwoOrMore(w)
        #strip punctuation
        w = w.strip('\'"?,.')
        #check if the word stats with an alphabet
        val = re.search(r"^[a-zA-Z][a-zA-Z0-9]*$", w)
        #ignore if it is a stop word
        if(w in stopWords or val is None):
            continue
        else:
            featureVector.append(w.lower())
    return featureVector


# extract features from tweet and check against all feature vectors
def extract_features(tweet):
    tweet_words = set(tweet)
    features = {}
    for word in featureList:
        features['contains(%s)' % word] = (word in tweet_words)
    return features


#=================== Begin program  =======================

stopWords = []
#Read the tweets from the training file which we manually annotated
inpTweets = csv.reader(open('training.csv', 'rb'), delimiter=',')
#get stop words
stopWords = getStopWordList('stopwords.txt')
featureList = []

# This is where we extract the tweet and the sentiment associated with it. Examines the training file and
# extracts the sentiment in a tuple with tuple(0) containing the sentiment and tuple(1) containing the tweet iteslf
tweets = []
for row in inpTweets:
    level = row[0]
    if(level == "1"):
        sentiment = ("Level 1:Strongly Negative")
    elif(level == "2"):
        sentiment = ("Level 2:Negative")
    elif(level == "3"):
        sentiment = ("Level 3:Positive")
    elif(level == "4"):
        sentiment = ("Level 4:Strongly Positive")

    tweet = row[1]
    # print "sentiment: " + sentiment + "\t\tTweet: " + tweet
    processedTweet = processTweet(tweet)
    featureVector = getFeatureVector(processedTweet)
    featureList.extend(featureVector)
    tweets.append((featureVector, sentiment));
#end loop

# Remove featureList duplicates
featureList = list(set(featureList))

# Extract feature vector for all tweets in one shote
training_set = nltk.classify.util.apply_features(extract_features, tweets)
print training_set


print("\n========================================= Maximum Entropy Classifier ===============================\n")

# this the implementation of the maximum enthropy classifier as by nltk
#Max Entropy Classifier
MaxEntClassifier = nltk.classify.maxent.MaxentClassifier.train(training_set, 'GIS', trace=3, encoding=None, labels=None, gaussian_prior_sigma=0, max_iter = 3)


inputFile = open('inputTestTweets.txt', 'r')
results = open('results.txt', 'w')#write to file
for line in inputFile:

    testTweet =  line
    # we need to scrub the tweet and take out the common words then pass it to the process function
    scrubbedTweet =""
    tweetarr = testTweet.split(" ")
    stopWords = open('stopwords.txt', 'r')



    for line in stopWords:
        line1 = line.strip("\n")
        if line1 in tweetarr:
            tweetarr.remove(line1)

    for i in range(len(tweetarr)):
        scrubbedTweet = scrubbedTweet + tweetarr[i] + " "

    print "\nOriginal tweet:" + testTweet
    print "Scrubbed tweet: " + scrubbedTweet
    processedTestTweet = processTweet(scrubbedTweet)
    print "Processed tweet: " +  processedTestTweet
    print "\nClassiication of tweet:"
    answer =  MaxEntClassifier.classify(extract_features(getFeatureVector(processedTestTweet)))

    results.write(answer + ": " + testTweet +"\n")

results.close()
inputFile.close()


#results
"""
For the maximum entropy program, in order to get accurate results. The program needed to be trained using manually annotated data, in our case, tweets from twitter regarding
Bernie Sanders. These tweets were pre processed so that features were able to have been better extracted. Feature vectors were created which consisted of
single words which were contained in the tweets. Common words were ignored, but for a negative tweet, for example "I hate Bernie Sanders #FeelTheBern", the words which were extracted and added
to the feature list would be hate. This tweet also would have been manually annotated to have a connotation of negative. In order to get a proper notion of sentiment for this tweet
example, we added common words such as "bernie" , "sanders", "hillary", "trump" etc to the list of stop words because they had no real contribution to the sentiment of
the tweet. When running the program, as the size of the input increased, it became increasingly difficult to get an accurate representation of the sentiment thus the removal of
those words. This algorithm was implemented using unigrams, so for example, for a positive tweet "I love Bernie Sanders" against a negative tweet "I hate
Bernie Sanders and but not Trump", the feature vectors would look similar to ["love", "bernie", "sanders"] and ["hate", "bernie", "sanders", "trump"] respectively.
For other tweets because of the unnecessary words and implementation of unigrams, this would assign incorrect sentiments to the tweets. When words that were assigned to have a connotation
of positive and those words were unique and seperate from the words that had connotations of negative, the algorithm worked fine. This is what was used for the implementation
of levels 1-4 of sentiments. Words such as "hate", "despise" etc were used for level 1(very negative) and words such as "love", "magnificent" etc were used for level 4(very positive).


"""