In order to run this program, you run the maximumEntropy.py file. You must have a file named "inputTestTweets" as the tweets that you want to get the sentiment for
and you must have a file "stopwords.txt" as well as a "trainin.csv" file which has the manually annotated data in the format "level of sentiment, tweet" for example
"3,My vote is #StillSanders" where 3 is the level and the rest is the tweet. The program will produce an output file named "results.txt" with the
 format "level of sentiment: tweet". All of the mentioned files are provided. Also, a file named "manuallyAnnotatedTrainingData.csv" is provided with manual annotation of tweets
 with positive and negative connotation.